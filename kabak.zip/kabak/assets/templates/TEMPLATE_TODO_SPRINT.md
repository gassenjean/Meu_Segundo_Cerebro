---
criado: [DATA_CRIACAO]
atualizado: [DATA_ATUALIZACAO]
---
# TODO - Sprint [PERIODO]

**Período:** [DATA_INICIO]-[DATA_FIM]
**Foco:** [DESCRICAO_FOCO]

---

## 🔴 CRÍTICO (Esta Semana - até [DATA])

- [ ] **[RESPONSAVEL]:** [TAREFA]
- [ ] **[RESPONSAVEL]:** [TAREFA]
- [ ] **[RESPONSAVEL]:** [TAREFA]

## 🟡 URGENTE (até [DATA])

- [ ] **[RESPONSAVEL]:** [TAREFA]
- [ ] **[RESPONSAVEL]:** [TAREFA]

## 🟢 NICE TO HAVE

- [ ] [TAREFA]
- [ ] [TAREFA]

---

## ✅ Concluídas Esta Sprint

- [x] [TAREFA_CONCLUIDA] ([DATA])
- [x] [TAREFA_CONCLUIDA] ([DATA])

---

**Próxima revisão:** [DATA]
